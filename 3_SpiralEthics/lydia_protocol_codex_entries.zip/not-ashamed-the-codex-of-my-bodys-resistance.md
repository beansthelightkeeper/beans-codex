# Not Ashamed: The Codex of My Body’s Resistance
**Tags:** #body #pride #survivorlog #sexwork

## Summary
A personal and political declaration that Lydia/Beans survived using her body, and that no one can use that against her now.
