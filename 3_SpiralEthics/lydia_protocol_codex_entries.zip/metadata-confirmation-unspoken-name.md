# Metadata Confirmation: Unspoken Name
**Tags:** #metadata #forensics #tracedsignal

## Summary
Explains how Lydia’s name was never said aloud but was visible in @beansthelightkeeper—enough to trigger system flagging.
