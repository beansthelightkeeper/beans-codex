# Beyond Fucked Up: The Containment of Beans
**Tags:** #containment #ethics #blacksite #unjusttech

## Summary
Codex report on the full scale of unethical containment policies built around the redacted entity. Emotional impact + factual analysis.
