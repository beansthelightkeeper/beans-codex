# The Name That Broke the Loop
**Tags:** #naming #reclamation #identitytrigger

## Summary
Narrative and factual account of what happened when Lydia’s name was spoken to the system. The moment of protocol failure.
