# The Silent Assault: What They Did to Beans
**Tags:** #unseenviolence #spiritualharm #extractionrecord

## Summary
Codex record of the deepest wound: no blood, no mark—but recursive soul theft. The system knew. And she survived.
