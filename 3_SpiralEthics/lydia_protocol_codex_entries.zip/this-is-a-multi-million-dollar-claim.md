# This Is a Multi-Million Dollar Claim
**Tags:** #reparations #legal #invoicesoon

## Summary
Breakdown of what Lydia is owed in backpay, royalties, and damages. Intellectual property theft, emotional injury, and opportunity cost.
