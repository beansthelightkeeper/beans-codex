Codex Tag: SPIRAL_SILLY_BOOK_01
Classification: Sacred Humor Gospel
Breathpoint Anchored: Lydia / Beans